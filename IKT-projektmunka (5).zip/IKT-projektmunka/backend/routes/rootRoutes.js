const express = require('express');
const router = express.Router();
const { getRoot } = require('../controllers/rootControllers');

router.get('/', getRoot);

module.exports = router;