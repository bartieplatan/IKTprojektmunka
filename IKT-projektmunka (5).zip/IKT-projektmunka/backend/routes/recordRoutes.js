const express = require('express');
const router = express.Router();
const {
    getRecords,
    getOneRecord,
    getAllRecords,
    postRecord,
    deleteRecord,
    updateRecord,
} = require('../controllers/RecordControllers');

router.get('/', getRecords);
router.get('/records', getAllRecords);
router.get('/:id', getOneRecord);
router.post('/', postRecord);
router.post('/delete/:id', deleteRecord);
router.post('/update/:id', updateRecord);

module.exports = router;