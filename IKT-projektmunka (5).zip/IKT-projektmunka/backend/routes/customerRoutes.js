const express = require('express');
const router = express.Router();
const {
    getAllCustomers,
    registerCustomer,
    loginCustomer,
    deleteCustomer,
} = require('../controllers/customerControllers');

router.get('/', getAllCustomers);
router.post('/register', registerCustomer);
router.post('/login', loginCustomer);
router.post('/delete/:id', deleteCustomer);

module.exports = router;
