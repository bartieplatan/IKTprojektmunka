const express = require("express");
const router = express.Router();

router.get("/", getallCustomers);
module.exports=router;