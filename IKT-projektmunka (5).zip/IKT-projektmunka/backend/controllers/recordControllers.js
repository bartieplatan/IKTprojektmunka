const Record = require('../models/Record');

const getRecords = async (req, res) => {
    try {
        const records = await Record.find();
        res.status(200).json(records);
    } catch (error) {
        res.status(500).json({ msg: 'Valami elromlott!' });
    }
};

const getOneRecord = async (req, res) => {
    try {
        const params = req.params;
        const records = await Record.findOne({ _id: params.id });
        console.log(records);
        res.status(200).json(records);
    } catch (error) {
        res.status(500).json({ msg: 'Valami elromlott!' });
    }
};

const getAllRecords = async (req, res) => {
    try {
        const records = await Record.find({});
        res.status(200).render('record', { records });
    } catch (error) {
        res.status(500).json({ msg: 'Valami elromlott itt!' + error.message });
    }
};

const postRecord = async (req, res) => {
    try {
        const { name, description, price, image } = req.body;
        console.log(req.body);
        const newRecord = new Record({ name, description, price, image });
        await newRecord.save();
        res.status(201).json(newRecord);
    } catch (error) {
        res.status(500).json({ msg: 'Valami elromlott!' });
    }
};

const deleteRecord = async (req, res) => {
    try {
        const param = req.params;
        console.log(param);
        const deleteRecord = await Record.findOneAndDelete({
            _id: param.id,
        });
        res.status(200).json({ msg: deleteRecord });
    } catch (error) {
        console.log(error.message);
        res.status(500).json({ msg: 'Valami hiba történt!' });
    }
};

const updateRecord = async (req, res) => {
    try {
        const param = req.params;
        const { name, description, price, image } = req.body;
        console.log({ name, description, price, image });
        const updateRecord = await Record.findOneAndUpdate(
            {
                _id: param.id,
            },
            { name, description, price, image },
            { new: true }
        );
        res.status(200).json({ msg: updateRecord });
    } catch (error) {
        console.log(error.message);
        res.status(500).json({ msg: 'Valami hiba történt!' });
    }
};

module.exports = {
    getRecords,
    getOneRecord,
    getAllRecords,
    postRecord,
    deleteRecord,
    updateRecord,
};