const Customer = require('../models/Customer');
const bcrypt = require('bcrypt');

exports.getAllCustomers = async (req, res) => {
    try {
        const customers = await Customer.find({});
        res.status(200).render('customer', { customers });
    } catch (error) {
        res.status(500).json({ msg: 'Valami hiba történt' });
    }
};

exports.registerCustomer = async (req, res) => {
    try {
        const { fname, lname, email, password } = req.body;
        const customer = await Customer.findOne({ email });

        if (customer) {
            return res.status(401).json({ msg: 'Ilyen vásárlónk már van!' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const newCustomer = new Customer({
            fname,
            lname,
            email,
            password: hashedPassword,
        });

        await newCustomer.save();

        console.log(newCustomer);
        res.status(200).json({ msg: newCustomer });
    } catch (error) {
        res.status(500).json({
            msg: 'Valami hiba történt a regisztráció során!' + error.message,
        });
    }
};

exports.loginCustomer = async (req, res) => {
    try {
        const { email, password } = req.body;
        const customer = await Customer.findOne({ email });

        if (!customer) {
            return res.status(500).json({ msg: 'Ilyen vásárlónk még nincs!' });
        }

        const osszehasonlit = await bcrypt.compare(password, customer.password);

        if (osszehasonlit) {
            res.status(200).json({ msg: customer });
        } else {
            return res.status(403).json({ msg: 'Nincs joga belépni!' });
        }
    } catch (error) {
        res.status(500).json({
            msg: 'Valami hiba történt a belépés során!' + error.message,
        });
    }
};

exports.deleteCustomer = async (req, res) => {
    try {
        const param = req.params;
        const deleteCustomer = await Customer.findOneAndDelete({
            _id: param.id,
        });
        res.status(200).json({ msg: deleteCustomer });
    } catch (error) {
        console.log(error.message);
        res.status(500).json({ msg: 'Valami hiba történt!' });
    }
};