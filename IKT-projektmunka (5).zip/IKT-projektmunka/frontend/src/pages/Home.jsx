import React, { useEffect, useState } from 'react';
import kep1 from '../images/kep1.png';
import kep9 from '../images/kep9.jpg';
import kep3 from '../images/kep7.png';
import { Link } from 'react-router-dom';

import './Home.css';
import { useDispatch } from 'react-redux';
import { addRecord } from '../redux/cartSlice';

const Home = () => {
    const [records, setRecords] = useState([]);
    const dispatch = useDispatch();

    useEffect(() => {
        const adatLeker = async () => {
            try {
                const response = await fetch('http://localhost:3500/record');
                const records = await response.json();

                if (response.ok) {
                    // console.log(records);
                    setRecords(records);
                } else {
                    console.log(records.msg);
                }
            } catch (error) {
                console.log(error);
            }
        };

        adatLeker();
    }, []);
    return (
        <div className="container">
            <div className="row">
                <div className="col-sm-6">
                    <div
                        id="carouselExampleCaptions"
                        className="carousel slide"
                        data-bs-ride="false"
                    >
                        <div className="carousel-indicators">
                            <button
                                type="button"
                                data-bs-target="#carouselExampleCaptions"
                                data-bs-slide-to="0"
                                className="active"
                                aria-current="true"
                                aria-label="Slide 1"
                            ></button>
                            <button
                                type="button"
                                data-bs-target="#carouselExampleCaptions"
                                data-bs-slide-to="1"
                                aria-label="Slide 2"
                            ></button>
                            <button
                                type="button"
                                data-bs-target="#carouselExampleCaptions"
                                data-bs-slide-to="2"
                                aria-label="Slide 3"
                            ></button>
                        </div>
                        <div className="carousel-inner">
                            <div className="carousel-item active">
                                <img
                                    src={kep1}
                                    className="d-block w-100"
                                    alt="..."
                                />
                                <div className="carousel-caption d-none d-md-block elso">
                                    <h5>Lustmord and Aethek</h5>
                                    <p>Scorn Soundtrack 2xLP (Black Vinyl)</p>
                                </div>
                            </div>
                            <div className="carousel-item">
                                <img
                                    src={kep9}
                                    className="d-block w-100"
                                    alt="..."
                                />
                                <div className="carousel-caption d-none d-md-block">
                                    <h5>Hotline Miami 1 & 2</h5>
                                    <p>
                                        The Complete Collection Boxset 8xLP
                                        (Black Vinyl)
                                    </p>
                                </div>
                            </div>
                            <div className="carousel-item">
                                <img
                                    src={kep3}
                                    className="d-block w-100"
                                    alt="..."
                                />
                                <div className="carousel-caption d-none d-md-block">
                                    <h5>Mick Gordon</h5>
                                    <p>
                                        Doom Original Game Soundtrack 2xLP (Red
                                        Vinyl)
                                    </p>
                                </div>
                            </div>
                        </div>
                        <button
                            className="carousel-control-prev"
                            type="button"
                            data-bs-target="#carouselExampleCaptions"
                            data-bs-slide="prev"
                        >
                            <span
                                className="carousel-control-prev-icon"
                                aria-hidden="true"
                            ></span>
                            <span className="visually-hidden">Previous</span>
                        </button>
                        <button
                            className="carousel-control-next"
                            type="button"
                            data-bs-target="#carouselExampleCaptions"
                            data-bs-slide="next"
                        >
                            <span
                                className="carousel-control-next-icon"
                                aria-hidden="true"
                            ></span>
                            <span className="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
                <div className="col-sm-6">
                    <h1>Record Label lemezbolt</h1>
                </div>
            </div>
            <div className="row">
                <div className="col-sm-6">
                    {records.map((elem) => (
                        <div key={elem._id}>
                            <Link key={elem._id} to={`/record/${elem._id}`}>
                                <p className="text-white">Cím: {elem.name}</p>
                                <p className="text-white">
                                    Leírás: {elem.description}
                                </p>
                                <p className="text-white">
                                    Ár: {elem.price} Ft
                                </p>
                                <img src={elem.image} alt="" />
                            </Link>
                            <button onClick={() => dispatch(addRecord(elem))}>
                                Kosárba tesz
                            </button>
                        </div>
                    ))}
                </div>
                <div className="col-sm-6">Második</div>
            </div>
        </div>
    );
};

export default Home;
