import React from "react";

import "./Faq.css";

var faq = document.getElementsByClassName("faq-page");
var i;
for (i = 0; i < faq.length; i++) {
    faq[i].addEventListener("click", function () {
        /* Toggle between adding and removing the "active" class,
        to highlight the button that controls the panel */
        this.classList.toggle("active");
        /* Toggle between hiding and showing the active panel */
        var body = this.nextElementSibling;
        if (body.style.display === "block") {
            body.style.display = "none";
        } else {
            body.style.display = "block";
        }
    });
}

const Faq = () => {
  return (
    <div>
      <p>faq</p>
    <h1 className="faq-heading">FAQ'S</h1>
    <section className="faq-container">
      <div className="faq-one">
        {/* faq question */}
        <h1 className="faq-page">What is an FAQ Page?</h1>
        {/* faq answer */}
        <div className="faq-body">
          <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Velit
            saepe sequi, illum facere necessitatibus cum aliquam id illo omnis
            maxime, totam soluta voluptate amet ut sit ipsum aperiam.
            Perspiciatis, porro!
          </p>
        </div>
        <hr className="hr-line" />
      <div className="faq-two">
        {/* faq question */}
        <h1 className="faq-page">Why do you a Vynil?</h1>
        {/* faq answer */}
        <div className="faq-body">
          <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Velit
            saepe sequi, illum facere necessitatibus cum aliquam id illo omnis
            maxime, totam soluta voluptate amet ut sit ipsum aperiam.
            Perspiciatis, porro!
          </p>
        </div>
      </div>
      <hr className="hr-line" />
      <div className="faq-three">
        {/* faq question */}
        <h1 className="faq-page">
          Do we gurantee the products safety?
        </h1>
        {/* faq answer */}
        <div className="faq-body">
          <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Velit
            saepe sequi, illum facere necessitatibus cum aliquam id illo omnis
            maxime, totam soluta voluptate amet ut sit ipsum aperiam.
            Perspiciatis, porro!
          </p>
        </div>
        </div>
      </div>
    </section>
    </div>
  );
};

export default Faq;