import { useEffect, useState } from 'react';

const History = () => {
    const [vasarlas, setVasarlas] = useState([]);
    const [nev, setNev] = useState('');
    const customer = localStorage.getItem('customer');

    useEffect(() => {
        const leker = async () => {
            try {
                const response = await fetch('http://localhost:3500/cart');
                const res = await response.json();

                if (response.ok) {
                    console.log(res);
                    let buying = [];
                    res.map((item) => {
                        if (item.customer.email === customer) {
                            buying.push(item);
                            setNev(
                                item.customer.fname + ' ' + item.customer.lname
                            );
                        }
                    });
                    setVasarlas(buying);
                } else {
                    console.log(res.msg);
                }
            } catch (error) {
                console.log(error.message);
            }
        };

        leker();
    }, []);

    return (
        <div>
            <h1 className="text-white">Vásárló neve: {nev}</h1>
            {vasarlas.map((item) => (
                <div key={item._id}>
                    <p className="text-white">
                        Vásárlás időpontja: {item.createdAt}
                    </p>
                    <p className="text-white">
                        Vásárlás végösszege: {item.amount} Ft
                    </p>
                    <p className="text-white">Tételek: </p>
                    <ul className="text-white">
                        {item.record.map((elem) => (
                            <li key={elem._id}>
                                <p>Cím: {elem.name}</p>
                                <img src={elem.image} alt="kép" />
                            </li>
                        ))}
                    </ul>
                </div>
            ))}
        </div>
    );
};

export default History;