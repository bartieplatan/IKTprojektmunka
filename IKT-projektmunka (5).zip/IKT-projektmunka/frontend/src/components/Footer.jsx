import React from "react";
import "./Footer.css";



const Footer = () => {
  return (
    <div>
      <p>Footer</p>
      <footer class="site-footer">
        <div class="container">
          <div class="row">
            <div class="col-sm-12 col-md-6">
              <h6>Bakelit webárúházunkról</h6>
              <p class="text-justify">
                Szerezze be az ország legjobb Bakelit lemezeit webárúházunkból!
              </p>
            </div>

            <div class="col-xs-6 col-md-3">
              <h6>Kategóriák</h6>
              <ul class="footer-links">
                <li>
                  <a href="">Copyright</a>
                </li>
                <li>
                  <a href="">Elérhetőségeink</a>
                </li>
                <li>
                  <a href="">Rólunk</a>
                </li>
                <li>
                  <a href="">FAQ</a>
                </li>
                <li>
                  <a href="">Forrásaink</a>
                </li>
              </ul>
            </div>

            <div class="col-xs-6 col-md-3">
              <h6>Boltunkról</h6>
              <ul class="footer-links">
                <li>
                  <a href="">Rólunk</a>
                </li>
                <li>
                  <a href="">Lépjen kapcsolatba velünk</a>
                </li>
                <li>
                  <a href="">Hozzájárul</a>
                </li>
                <li>
                  <a href="">Adatvédelmi irányelvek</a>
                </li>
                <li>
                  <a href="">Webhelytérkép</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="container">
          <div class="row">
          <div class="col-md-8 col-sm-6 col-xs-12">
            <p class="copyright-text">Copyright &copy; 2022 Minden jog fenntartva
         <a href="# "> Recordlabel</a>.
            </p>
            </div>

            <div class="col-md-4 col-sm-6 col-xs-12">
              <ul class="social-icons">
                <li>
                  <a class="facebook" href="#">
                    <i class="fa fa-facebook"></i>
                    <img src="facebook.png"></img>
                  </a>
                </li>
                <li>
                  <a class="twitter" href="#">
                    <i class="fa fa-twitter"></i>
                    <img src="twitter.png"></img>
                  </a>
                </li>
                <li>
                  <a class="dribbble" href="#">
                    <i class="fa fa-dribbble"></i>
                    <img src="instagram.png"></img>
                  </a>
                </li>
                <li>
                  <a class="linkedin" href="#">
                    <i class="fa fa-linkedin"></i>
                    <img src="linkedin.png"></img>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Footer;