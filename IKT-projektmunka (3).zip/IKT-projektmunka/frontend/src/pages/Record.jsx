import React from 'react';

const Record = () => {
  return <div>Record</div>;
};

export default Record;
