import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    value: 0,
    amount: 0,
    records: [],
};

export const cartSlice = createSlice({
    name: 'cart',
    initialState,
    reducers: {
        addRecord: (state, action) => {
            let vane = true;
            for (let i = 0; i < state.records.length; i++) {
                if (action.payload._id === state.records[i]._id) {
                    vane = false;
                    break;
                }
            }

            if (vane) {
                state.value += 1;
                state.amount += action.payload.price;
                state.records.push(action.payload);
            }
        },
        removeRecord: (state, action) => {
            state.value -= 1;
            state.amount -= action.payload.price;
            state.records = state.records.filter(
                (element) => element._id !== action.payload._id
            );
        },
        clearRecords: (state) => {
            state.value = 0;
            state.amount = 0;
            state.records = [];
        },
    },
});

export const { addRecord, removeRecord, clearRecords } = cartSlice.actions;

export default cartSlice.reducer;
