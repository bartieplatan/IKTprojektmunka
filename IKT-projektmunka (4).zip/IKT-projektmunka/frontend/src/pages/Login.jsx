import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    function handleSubmit(e) {
        e.preventDefault();

        let kuld = async () => {
            try {
                console.log(email, password);
                const response = await fetch(
                    'http://localhost:3500/customer/login',
                    {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            email,
                            password,
                        }),
                    }
                );

                const res = await response.json();

                if (response.ok) {
                    window.alert('Sikeresen bejelentkezett!');
                    localStorage.setItem('isLoggedIn', true);
                    localStorage.setItem('customer', email);
                    if (password === 'admin1' || password === 'admin2') {
                        localStorage.setItem('isAdmin', true);
                        localStorage.setItem('customer', 'admin');
                    }
                    navigate('/');
                } else {
                    window.alert(res.msg);
                }
            } catch (error) {
                console.log(error.message);
            }
        };

        kuld();
    }

    return (
        <div className="auth-wrapper">
            <div className="auth-inner">
                <form>
                    <h3>Login</h3>

                    <div className="mb-3">
                        <label>Email address</label>
                        <input
                            type="email"
                            className="form-control"
                            placeholder="Enter email"
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    </div>

                    <div className="mb-3">
                        <label>Password</label>
                        <input
                            type="password"
                            className="form-control"
                            placeholder="Enter password"
                            onChange={(e) => setPassword(e.target.value)}
                        />
                    </div>

                    {/* <div className="mb-3">
                        <div className="custom-control custom-checkbox">
                            <input
                                type="checkbox"
                                className="custom-control-input"
                                id="customCheck1"
                            />
                            <label
                                className="custom-control-label"
                                htmlFor="customCheck1"
                            >
                                Remember me
                            </label>
                        </div>
                    </div> */}

                    <div className="d-grid">
                        <button
                            type="submit"
                            className="btn btn-primary"
                            onClick={handleSubmit}
                        >
                            Submit
                        </button>
                    </div>
                    <p className="forgot-password text-right text-white">
                        Don't have an account?<a href="/Register">Register!</a>
                    </p>
                </form>
            </div>
        </div>
    );
}
