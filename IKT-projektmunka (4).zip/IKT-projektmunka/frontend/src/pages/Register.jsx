import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Register() {
    const [fname, setFname] = useState('');
    const [lname, setLname] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleSubmit = (event) => {
        event.preventDefault();

        const feltolt = async () => {
            try {
                const response = await fetch(
                    'http://localhost:3500/customer/register',
                    {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            fname,
                            lname,
                            email,
                            password,
                        }),
                    }
                );

                console.log(response);
                const res = await response.json();

                if (response.ok) {
                    window.alert('Sikeres regisztráció!');
                    localStorage.setItem('isLoggedIn', true);
                    localStorage.setItem('customer', email);
                    console.log(res.msg);
                    navigate('/');
                } else {
                    window.alert(res.msg);
                }
            } catch (error) {
                console.log(error.message);
            }
        };

        feltolt();
    };

    return (
        <div className="auth-wrapper">
            <div className="auth-inner">
                <form>
                    <h3>Register</h3>

                    <div className="mb-3">
                        <label>First name</label>
                        <input
                            type="text"
                            className="form-control"
                            placeholder="First name"
                            onChange={(e) => setFname(e.target.value)}
                        />
                    </div>

                    <div className="mb-3">
                        <label>Last name</label>
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Last name"
                            onChange={(e) => setLname(e.target.value)}
                        />
                    </div>

                    <div className="mb-3">
                        <label>Email address</label>
                        <input
                            type="email"
                            className="form-control"
                            placeholder="Enter email"
                            onChange={(e) => setEmail(e.target.value)}
                        />
                    </div>

                    <div className="mb-3">
                        <label>Password</label>
                        <input
                            type="password"
                            className="form-control"
                            placeholder="Enter password"
                            onChange={(e) => setPassword(e.target.value)}
                        />
                    </div>

                    <div className="d-grid">
                        <button
                            className="btn btn-primary"
                            onClick={handleSubmit}
                        >
                            Register
                        </button>
                    </div>
                    <p className="forgot-password text-right text-white">
                        Already registered ?<a href="/login">Login!</a>
                    </p>
                </form>
            </div>
        </div>
    );
}
