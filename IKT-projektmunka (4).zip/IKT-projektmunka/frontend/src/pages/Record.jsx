import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { addRecord } from '../redux/cartSlice';

const Record = () => {
    const [lemez, setLemez] = useState({});
    const param = useParams();
    const dispatch = useDispatch();

    useEffect(() => {
        console.log(param.id);
        const leker = async () => {
            try {
                const response = await fetch(
                    `http://localhost:3500/record/${param.id}`
                );

                const res = await response.json();

                if (response.ok) {
                    console.log(res);
                    setLemez(res);
                } else {
                    console.log(res.msg);
                }
            } catch (error) {
                console.log(error.message);
            }
        };

        leker();
    }, [param.id]);

    return (
        <div className="record-container">
            <ul>
                <h1>{lemez.name}</h1>
                <p>{lemez.description}</p>
                <p>{lemez.price} Ft</p>
                <img src={lemez.image} alt="kép" />
                <button onClick={() => dispatch(addRecord(lemez))}>
                    Kosárba tesz
                </button>
            </ul>
        </div>
    );
};

export default Record;
