import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { clearRecords, removeRecord } from '../redux/cartSlice';
import { useNavigate } from 'react-router-dom';

const Cart = () => {
    const record = useSelector((state) => state.cart);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    console.log(record.value);
    console.log(record.records);

    const fizetes = () => {
        console.log(record.records);
        console.log(record.amount);
        const customer = localStorage.getItem('customer');
        const records = record.records;
        const amount = record.amount;
        const kuld = async () => {
            try {
                const response = await fetch('http://localhost:3500/cart', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ customer, records, amount }),
                });

                const res = await response.json();

                if (response.ok) {
                    console.log(res);
                    dispatch(clearRecords());
                    navigate('/history');
                } else {
                    console.log(res.msg);
                }
            } catch (error) {
                console.log(error.message);
            }
        };

        kuld();
    };

    return (
        <div className="text-white">
            {record.records.map((element) => (
                <div key={element._id}>
                    <h1>{element.name}</h1>
                    <p className="text-white">{element.description}</p>
                    <p>{element.price} Ft</p>
                    <img src={element.image} alt="kép" />
                    <button onClick={() => dispatch(removeRecord(element))}>
                        Töröl
                    </button>
                </div>
            ))}
            <p>Fizetendő: {record.amount} Ft</p>
            <button onClick={fizetes}>Fizetés</button>
        </div>
    );
};

export default Cart;