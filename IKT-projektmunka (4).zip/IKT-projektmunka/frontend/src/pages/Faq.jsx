import React from "react";

import "./Faq.css";

const Faq = () => {
  return (
    <div>
      <p>faq</p>
    </div>
  );
};

export default Faq;