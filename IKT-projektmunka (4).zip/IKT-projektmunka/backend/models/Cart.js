const mongoose = require('mongoose');
const Customer = require('./Customer');
const Record = require('./Record');

const cartSchema = new mongoose.Schema(
    {
        customer: {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'customer',
        },
        record: [
            {
                type: mongoose.Schema.Types.ObjectId,
                ref: 'record',
            },
        ],
        amount: {
            type: Number,
        },
    },
    { timestamps: true }
);

module.exports = mongoose.model('cart', cartSchema);