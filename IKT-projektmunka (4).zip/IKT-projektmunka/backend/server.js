require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

const app = express();
app.set('view engine', 'ejs');
// app.use(express.static(path.join(__dirname, 'public')));
app.use(express.static('public'));
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use('/', require('./routes/rootRoutes'));
app.use('/customer', require('./routes/customerRoutes'));
app.use('/record', require('./routes/recordRoutes'));
app.use('/cart', require('./routes/cartRoutes'));

const PORT = process.env.PORT || 3500;

mongoose.set('strictQuery', false);
mongoose
    .connect(process.env.MONGO_URI)
    .then(() => console.log('Sikeres csatlakozás!'))
    .catch((err) => console.log(err));
app.listen(PORT, () => {
    console.log(`http://localhost:${PORT}`);
});
