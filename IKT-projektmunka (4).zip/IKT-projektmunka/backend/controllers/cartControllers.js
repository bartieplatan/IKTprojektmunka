const Cart = require('../models/Cart');
const Customer = require('../models/Customer');
const Record = require('../models/Record');

const getCarts = async (req, res) => {
    try {
        const carts = await Cart.find().populate('customer').populate('record');
        // console.log(carts);
        res.status(200).json(carts);
    } catch (error) {
        res.status(500).json({ msg: 'Valami hiba történt!' + error.message });
    }
};

const getAllCarts = async (req, res) => {
    try {
        const carts = await Cart.find().populate('customer').populate('record');
        // console.log(carts);
        res.status(200).render('cart', { carts });
    } catch (error) {
        res.status(500).json({ msg: 'Valami hiba történt!' + error.message });
    }
};

const postCart = async (req, res) => {
    try {
        const { customer, records, amount } = req.body;
        console.log({ customer, records, amount });
        const cust = await Customer.findOne({ email: customer });
        const newCart = new Cart({
            customer: cust._id,
            record: records,
            amount,
        });
        await newCart.save();
        res.status(201).json(newCart);
    } catch (error) {
        res.status(500).json({ msg: 'Valami hiba történt!' });
    }
};

const deleteCart = async (req, res) => {
    try {
        const param = req.params;
        const deleteCart = await Cart.findOneAndDelete({
            _id: param.id,
        });
        res.status(200).json({ msg: deleteCart });
    } catch (error) {
        console.log(error.message);
        res.status(500).json({ msg: 'Valami hiba történt!' });
    }
};

module.exports = { getCarts, getAllCarts, postCart, deleteCart };