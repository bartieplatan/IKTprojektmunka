exports.getallCustomers = (req, res) => {
  try {
  } catch (error) {
    res.status(500).json({ msg: "Valami hiba történt" });
  }
};