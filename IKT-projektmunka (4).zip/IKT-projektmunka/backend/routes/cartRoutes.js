const express = require('express');
const router = express.Router();
const {
    getCarts,
    getAllCarts,
    postCart,
    deleteCart,
} = require('../controllers/cartControllers');

router.get('/', getCarts);
router.get('/carts', getAllCarts);
router.post('/', postCart);
router.post('/delete/:id', deleteCart);

module.exports = router;
