const express = require("express");
const app = express();

// API végpontok
app.get("/api/users", (req, res) => {
  // Felhasználók lekérdezése az adatbázisból
});

app.post("/api/users", (req, res) => {
  // Új felhasználó létrehozása az adatbázisban
});

// API indítása
const port = 3000;
app.listen(port, () => {
  console.log(`API fut a ${port} porton.`);
});


